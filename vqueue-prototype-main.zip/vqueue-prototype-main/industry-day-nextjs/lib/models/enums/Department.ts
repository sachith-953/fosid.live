export enum Department {
    ZL = 'ZL',
    BT = 'BT',
    CH = 'CH',
    MT = 'MT',
    PH = 'PH',
    CSST = 'CSST',
    GL = 'GL',
    MB = 'MB',
    ES = 'ES'
}
