export enum StallStatus {
    OPEN = 'open',
    TEMP_CLOSED = 'temp_closed',
    CLOSED = 'closed'
}
