export enum QueueStatus {
    EMPTY = 'empty',
    OVERLOADED = 'overloaded',
    AVAILABLE = 'available'
}
