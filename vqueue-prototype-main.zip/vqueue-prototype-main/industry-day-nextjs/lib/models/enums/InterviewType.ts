export enum InterviewType {
    PRE_LIST = 'P',
    WALK_IN = 'W'
}
