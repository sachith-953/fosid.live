export enum Role {
  ADMIN = "admin",
  COMPANY_ADMIN = "companyAdmin",
  ROOM_ADMIN = "roomAdmin",
  STUDENT = "student",
}
