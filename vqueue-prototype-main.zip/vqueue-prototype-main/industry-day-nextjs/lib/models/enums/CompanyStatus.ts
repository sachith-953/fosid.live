export enum CompanyStatus {
    PRESENT = 'present',
    ABSENT = 'absent',
    CLOSED = 'closed'
}
