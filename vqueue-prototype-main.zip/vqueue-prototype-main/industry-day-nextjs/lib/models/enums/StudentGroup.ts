export enum StudentGroup {
    GN = 'GN',
    ZL = 'ZL',
    BT = 'BT',
    CH = 'CH',
    MT = 'MT',
    BMS = 'BMS',
    ST = 'ST',
    GL = 'GL',
    CS = 'CS',
    DS = 'DS',
    ML = 'ML',
    BL = 'BL',
    MB = 'MB',
    CM = 'CM',
    AS = 'AS',
    ES = 'ES',
    SOR = 'SOR'
}
