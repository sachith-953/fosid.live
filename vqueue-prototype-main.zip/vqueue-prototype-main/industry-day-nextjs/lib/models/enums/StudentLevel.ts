export enum StudentLevel {
  LEVEL_300 = "300L",
  LEVEL_400 = "400L",
  GRADUATE = "GRADUATE",
}
