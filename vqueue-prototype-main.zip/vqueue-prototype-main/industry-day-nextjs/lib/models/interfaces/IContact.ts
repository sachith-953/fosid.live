export interface IContact {
    id: string;
    phone1: string;
    phone2: string;
}
