export interface IMessage {
    id: string;
    email: string;
    message: string;
    createdAt: Date;
    updatedAt: Date;
    deletedAt: Date;
}