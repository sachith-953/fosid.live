import { library } from '@fortawesome/fontawesome-svg-core';
import { faFileImport, faFileCsv } from '@fortawesome/free-solid-svg-icons';

library.add(faFileImport, faFileCsv);