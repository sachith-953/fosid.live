export default function Company() {
    return (
      <div>This is the company route</div>
    );
  }