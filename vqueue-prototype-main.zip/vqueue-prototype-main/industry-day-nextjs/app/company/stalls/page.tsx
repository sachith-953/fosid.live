export default function CompanyStalls() {
    return (
      <div>This is the company-stalls route</div>
    );
  }