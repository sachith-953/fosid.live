export default function CompanyDashboard() {
    return (
      <div>This is the company-dashboard route</div>
    );
  }