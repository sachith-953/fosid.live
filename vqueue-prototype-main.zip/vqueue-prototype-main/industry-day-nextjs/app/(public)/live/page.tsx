import LiveUpdates from "@/components/vq/live-updates";


export default function Page() {
    return (
        <LiveUpdates />
    )
}