import React from "react";
import InterviewsList from "@/components/vq/interviewsList";

export default function Page() {
  return (
    <div className="w-full">
      <InterviewsList />
    </div>
  );
}
