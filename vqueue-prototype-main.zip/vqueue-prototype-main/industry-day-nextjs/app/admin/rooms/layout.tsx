export default function AdminRoomsLayout({children, }:{children:React.ReactNode}) {
    return (
      <div>
        <h1>AdminRooms Layout</h1>
        {children}
      </div>
    );
  }