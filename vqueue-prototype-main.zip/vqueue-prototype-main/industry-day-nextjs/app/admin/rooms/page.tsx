export default function AdminRooms() {
    return (
      <div>This is the admin-rooms route</div>
    );
  }