export default function Admin() {
  return <div>This is the admin route</div>;
}
