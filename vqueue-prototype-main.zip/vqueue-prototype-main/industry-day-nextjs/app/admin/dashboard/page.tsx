export default function AdminDashboard() {
    return (
      <div>This is the admin-dashboard route</div>
    );
  }