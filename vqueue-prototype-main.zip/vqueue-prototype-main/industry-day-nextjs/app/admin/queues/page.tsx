
import QueuesList from "@/components/vq/queuesList";

export default async function Page() {
  return (
    <div className="w-full">
      <QueuesList />
    </div>
  );
}
