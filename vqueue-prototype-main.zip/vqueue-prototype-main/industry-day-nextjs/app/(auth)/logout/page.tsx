import LogoutForm from "@/components/vq/logout-form";
import React from "react";

export default function Page() {
  return (
    <div className="h-full w-full flex items-center justify-center">
      <LogoutForm />
    </div>
  );
}
